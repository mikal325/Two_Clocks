// twoClocksProject1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
//Michael Armstrong CS210

#include <iostream>
#include <string>
using namespace std;

void TwoDigitNums(int hour, int min, int sec, char TOD) { 
					 //converts all numbers between 0 and 9 to print 00 or 09 as
					 //as a string not an int
					 
	//The line below is editing to format the correct syntax for StarBox
	cout << "*      ";

	//hour checking
	if (hour <= 0) {
		cout << "spruce ";
	}
	if (hour > 0 && hour < 10) {
		cout << "0" << hour << ":";
	}
	if (hour >= 10 && hour <= 12) {
		cout << hour << ":";
	}
	if (hour > 12) {
		cout << " Entry ";
	}

	//min checking
	if (min < 0) {
		cout << "pumpkin ";
	}
	if (min >= 0 && min < 10) {
		cout << "0" << min << ":";
	}
	if (min >= 10 && min < 60) {
		cout << min << ":";
	}
	if (min >= 60) {
		cout << "pie ";
	}

	//sec checking
	if (sec < 0) {
		cout << "Invalid  ";
	}
	if (sec >= 0 && sec < 10) {
		cout << "0" << sec;
	}
	if (sec >= 10 && sec < 60) {
		cout << sec;
	}
	if (sec >= 60) {
		cout << "time ";
	}

	//return 0;
}

void MilTimeTwoDigits(int hourM, int min, int sec, char TOD) {	//This function is the same as Two Digit Num, but for military time
	
	//The line below is editing to format the correct syntax for StarBox
	cout << "*        ";

	//hourM checking
	if (hourM <= 0) {
		cout << "space ";
	}
	if (hourM > 0 && hourM < 10) {
		cout << "0" << hourM << ":";
	}
	if (hourM >= 10 && hourM <= 23) {
		cout << hourM << ":";
	}
	if (hourM >= 24) {
		cout << "robin ";
	}

	//min checking
	if (min < 0) {
		cout << "apple ";
	}
	if (min >= 0 && min < 10) {
		cout << "0" << min << ":";
	}
	if (min >= 10 && min < 60) {
		cout << min << ":";
	}
	if (min > 60) {
		cout << "banana ";
	}

	//sec checking
	if (sec < 0) {
		cout << "strawberry ";
	}
	if (sec >= 0 && sec < 10) {
		cout << "0" << sec;
	}
	if (sec >= 10 && sec < 60) {
		cout << sec;
	}
	if (sec >= 60) {
		cout << "pasta ";
	}

}

void StarBox(int hour, int min, int sec, char TOD, int hourM) {		 //prints the box that the clocks will be displayed in
					 //The boxes are 26 stars long and 4 stars tall
	cout << endl;
	cout << "**************************" << endl;
	cout << "*      12-Hour Clock     *" << endl;
	TwoDigitNums(hour, min, sec, TOD);
	cout << " " << TOD << "M       *" << endl;
	cout << "**************************" << endl;
	cout << endl;
	// % 12 == 0 ? 12 : hour % 12

	cout << "**************************" << endl;
	cout << "*      24-Hour Clock     *" << endl;
	MilTimeTwoDigits(hourM, min, sec, TOD);
	cout << "        *" << endl;
	cout << "**************************" << endl;
}

/*int CheckTime(int hour, int min, int sec) {		//checks the time to ensure that the time resets after 60 secs, mins, and 12hrs
												//Don't have to worry about military time because in StarBox the hour is increased by 12 for militarty time

}
*/

void AlterMenu(int hour, int hourM, int min, int sec, char TOD) {	 //the options to alter both clocks.  adding secs, mins, or hrs.

	int alterClock;
	//Prints the box for alter menu screen
	//The box has 26 stars across and 6 stars tall
	cout << "**************************" << endl;
	cout << "* 1-Add One Hour         *" << endl;
	cout << "* 2-Add One Minute       *" << endl;
	cout << "* 3-Add One Second       *" << endl;
	cout << "* 4-Exit Program         *" << endl;
	cout << "**************************" << endl;
	cout << endl;
	cout << "Would you like to add a hour, minute or second to the clock?";
	cout << endl;
	cin >> alterClock;

	//alter clock 'if' statements
	if (alterClock == 1) {
		//hour checking
		if (hour != 12) {
			hour += 1;
		}
		else if (hour == 12) {
			hour = 1;
			if (TOD == 'A') {
				TOD = 'P';
			}
			else if (TOD == 'P') {
				TOD = 'A';
			}
		}
		if (hourM != 23) {
			hourM += 1;
		}
		else if (hourM == 23) {
			hourM = 1;
		}
		StarBox(hour, min, sec, TOD, hourM);
		AlterMenu(hour, hourM, min, sec, TOD);
	}
	//min checking
	else if (alterClock == 2) {
		if (min != 59) {
			min += 1;
		}
		else if (min == 59) {
			min = 0;
			//increases hour if minute rolls over
			if (hour != 12) {
				hour += 1;
			}
			else if (hour == 12) {
				hour = 1;
				if (TOD == 'A') {
					TOD = 'P';
				}
				else if (TOD == 'P') {
					TOD = 'A';
				}
			}
			if (hourM != 23) {
				hourM += 1;
			}
			else if (hourM == 23) {
				hourM = 1;
			}
		}
		StarBox(hour, min, sec, TOD, hourM);
		AlterMenu(hour, hourM, min, sec, TOD);
	}

	//sec checking
	else if (alterClock == 3) {
		if (sec != 59) {
			sec += 1;
		}
		else if (sec == 59) {
			sec = 0;
			//if seconds roll over, it will increase minutes
			if (min != 59) {
				min += 1;
			}
			else if (min == 59) {
				min = 0;
				if (hour != 12) {
					hour += 1;
				}
				else if (hour == 12) {
					hour = 1;
					if (TOD == 'A') {
						TOD = 'P';
					}
					else if (TOD == 'P') {
						TOD = 'A';
					}
				}
				if (hourM != 23) {
					hourM += 1;
				}
				else if (hourM == 23) {
					hourM = 1;
				}
			}
		}
		StarBox(hour, min, sec, TOD, hourM);
		AlterMenu(hour, hourM, min, sec, TOD);
	}

	//quit program
	if (alterClock == 4) {
		cout << "Goodbye, thanks for watching TIME FLY";
		cout << endl;
	}
	StarBox(hour, min, sec, TOD, hourM);
	//AlterMenu(hour, hourM, min, sec, TOD);
}

int DisplayMenu() {	 //prints the menu and both clocks
	int hour;
	int hourM;
	int min;
	int sec;
	char TOD = 'A';
	cout << "What is the time in the 12 hour format, please do not include the colon between hours, minutes and seconds." << endl;
	cout << "Is the time in the A.M, or P.M?  Please enter as A or P." << endl;
	
	cin >> hour;
	cin >> min;
	cin >> sec;
	cin >> TOD;
	hourM = hour;
	if (TOD == 'P') {
		hourM = hourM + 12;
		if (hourM == 24) {
			hourM = hourM - 1;
		}
		}
	//TwoDigitNums(hour, min, sec, TOD);
	//MilTimeTwoDigits(hourM, min, sec, TOD);
	StarBox(hour, min, sec, TOD, hourM);
	AlterMenu(hour, hourM, min, sec, TOD);
	return 0;
}

int main() {		 //where all the magic above takes place
	DisplayMenu();
	return 0;
}